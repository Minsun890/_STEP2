/* global QUnit */

sap.ui.require(["zwbsglastep2/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
