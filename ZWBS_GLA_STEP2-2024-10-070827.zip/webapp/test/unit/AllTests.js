sap.ui.define([
	"zwbs_gla_step2/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
